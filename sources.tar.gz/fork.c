#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main ()
{
pid_t child_pid;

printf ("PID of main program = %d\n", (int) getpid () );
child_pid = fork();

if ( child_pid != 0 )  
	{
	printf ("We are in parent process,it's PID=%d\n", (int) getpid()); 
	printf("PID of child=%d\n", (int) child_pid);
	}
	else
           printf("We are in child process, it's PID=%d\n", (int) getpid());

return 0;
}
