#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

sig_atomic_t child_exit_status;

int spawn (char *program, char **arg_list)
{
pid_t child_pid;

child_pid = fork();

if ( child_pid != 0)
	return child_pid;
	else {
 	       execvp(program,arg_list);
 	       fprintf (stderr,"an error ocurred in execvp\n");
	       abort();
	        }
}

void clean_up_child_process (int signal_number)
{
int status;
wait (&status);
child_exit_status = status;
}

int main ()
{
struct sigaction sigchld_action;
char* arg_list[] = {
"sleep", 
"60",
NULL 
};

memset (&sigchld_action, 0, sizeof (sigchld_action));

sigchld_action.sa_handler = &clean_up_child_process;
sigaction (SIGCHLD, &sigchld_action, NULL);

spawn ("sleep", arg_list);

return 0;
}
