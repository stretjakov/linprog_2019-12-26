#include <stdio.h>
#include <unistd.h>

int main ()
{
printf ("Parent process id  = %d\n", (int) getppid());
return 0;
}
