#include <pthread.h>
#include <stdio.h>



void* char_print (void *unused)
{
int i,j,old_cancel_state;

pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

for (i=0; i< 100 ; ++i ) {
	fputc ('-', stderr);
	pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,&old_cancel_state);
	fputc('(', stderr);
	for (j=0; j < 10; j++)
		fputc('+',stderr);
	fputc(')', stderr);
	pthread_setcancelstate(old_cancel_state,NULL);
	}
printf("\nNo cancel signal is obtained!\n");

return NULL;
}





int main ()
{
pthread_attr_t attr;
pthread_t thread;
int i;



pthread_create (&thread, NULL, &char_print, NULL);

for (i=0; i< 1000 ; ++i ) {
	fputc ('_',stderr);
	if ( i > 200) pthread_cancel(thread);
	}

fputc('\n',stderr);

pthread_join(thread,NULL);

return 0;
}
