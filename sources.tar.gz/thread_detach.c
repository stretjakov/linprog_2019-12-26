#include <pthread.h>
#include <stdio.h>



void* char_print (void *unused)
{
int i;

for (i=0; i< 200 ; ++i )
	fputc ('-', stderr);


return NULL;
}





int main ()
{
pthread_attr_t attr;
pthread_t thread;
int i;

pthread_attr_init (&attr);
pthread_attr_setdetachstate (&attr, PTHREAD_CREATE_DETACHED);


pthread_create (&thread, &attr, &char_print, NULL);
pthread_attr_destroy (&attr);

for (i=0; i< 1000 ; ++i )
	fputc ('+',stderr);

fputc('\n',stderr);

return 0;
}
