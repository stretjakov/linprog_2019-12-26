#include <stdio.h>
#include <unistd.h>

int main ()
{
printf ("Process id  = %d\n", (int) getpid());
return 0;
}
